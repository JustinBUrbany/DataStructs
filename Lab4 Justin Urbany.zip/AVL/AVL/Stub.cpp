/*************************************************************
* Author:		Justin.Urbany
* Filename:		Stub.cpp
* Date Created:	2/19/17
* Modifications:	2/21/17 -Built Test code
*					2/21/17 -added memory leak checker
*					2/22/17 -Added Comments
**************************************************************/
#define _CRTDB_MAP_ALLOC
#include <iostream>
using std::cout;
using std::endl;
#include "AVL.h"
#include <crtdbg.h>


/**********************************************************************
* Purpose: The purpose of this function is to Display a value that is
*	passed in to the screen
*
* Precondition: A value must be passed to the function to be displayed
*
* Postcondition: The value must be displayed to the screen
*
************************************************************************/
template<typename T>
void PrintTree(T data);

/*************************************************************
*
* Lab/Assignment: Lab 4-AVL Tree
*
* Overview:
*	The Idea of this program is to build an avl tree or
*	self balancing binary search tree. The AVL Tree inherits
*	from the binary search tree and adds the rebalancing
*	feature.
*
* Input:
*   This program doesn't take any input.
*
* Output:
*   The output of this program is speciffically designed to
*	print out all values in the tree in Breath First Order
************************************************************/
int main()
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	AVL<int> testtree;
	AVL<int> testtree2;

	cout << "Insert 7" << endl;
	testtree.Insert(7);
	cout << "Insert 5" << endl;
	testtree.Insert(5);
	cout << "Insert 6" << endl;
	testtree.Insert(6);

	cout << "Breath First Traversal Print: ";

	testtree.Print(PrintTree);
	cout << endl;

	cout << "Insert 15" << endl;
	testtree.Insert(15);

	cout << "Breath First Traversal Print: ";

	testtree.Print(PrintTree);
	cout << endl;
	cout << "Insert 14" << endl;
	testtree.Insert(14);

	cout << "Breath First Traversal Print: ";

	testtree.Print(PrintTree);
	cout << endl;


	cout << "Insert 25:" << endl;
	testtree.Insert(25);

	cout << "Breath First Traversal Print: ";

	testtree.Print(PrintTree);
	cout << endl;


	cout << "Insert 3:" << endl;
	testtree.Insert(3);
	cout << "Breath First Traversal Print: ";

	testtree.Print(PrintTree);



	cout << "Test OP Equals" << endl;
	testtree2 = testtree;

	cout << endl;

	cout << "Breath First Traversal Print New Tree: ";


	testtree2.Print(PrintTree);

	cout << endl;

	cout << "Delete 14: " << endl;
	testtree.Delete(14);
	cout << "Breath First Traversal Print: ";

	cout << endl;
	testtree.Print(PrintTree);



	testtree.Insert(14);

	cout << endl;
	testtree.Print(PrintTree);

	cout << "Breath First Traversal Print: ";
	testtree.Insert(12);

	cout << endl;

	cout << "Breath First Traversal Print: ";

	testtree.Print(PrintTree);
	cout << endl;





	AVL<double> dtesttree;
	
	cout << "New Tree Insert 8" << endl;
	dtesttree.Insert(8.0);
	cout << "New Tree Insert 9" << endl;
	dtesttree.Insert(9.0);
	cout << "New Tree Insert 10" << endl;
	dtesttree.Insert(10.0);
	cout << "New Tree Insert 2" << endl;
	dtesttree.Insert(2.0);
	cout << "New Tree Insert 1" << endl;
	dtesttree.Insert(1.0);
	cout << "New Tree Insert 5" << endl;
	dtesttree.Insert(5.0);
	cout << "New Tree Insert 6" << endl;
	dtesttree.Insert(6.0);
	cout << "New Tree Insert 3" << endl;
	dtesttree.Insert(3.0);
	cout << "New Tree Insert 4" << endl;
	dtesttree.Insert(4.0);
	cout << "New Tree Insert 7" << endl;
	dtesttree.Insert(7.0);
	cout << "New Tree Insert 11" << endl;
	dtesttree.Insert(11.0);



	cout << "Printing New Tree In Breath First Order: ";
	dtesttree.Print(PrintTree);




	return 0;
}


template<typename T>
void PrintTree(T data)
{
	cout << data << ' ';
}