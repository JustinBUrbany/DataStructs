#ifndef AVL_H
#define AVL_H
#include "BinarySearchTree.h"



template<typename T>
class AVL : BinaryTree<T>
{

public:
	AVL();
	AVL(AVL & copy);
	~AVL();
	AVL & operator =(AVL & rhs);

private:

	int m_balance;

};


#endif

template<typename T>
inline AVL<T>::AVL()
{
}

template<typename T>
inline AVL<T>::AVL(AVL & copy)
{
}

template<typename T>
inline AVL<T>::~AVL()
{
}

template<typename T>
inline AVL<T> & AVL<T>::operator=(AVL & rhs)
{
	return 0;
}
