#ifndef LIST_H
#define LIST_H
#include "Node.h"


template<typename T>
class List
{
public:
	List();
	List(const List & copy);
	~List();
	List & operator =(const List & rhs);
	bool isEmpty();
	const T & First();
	const T & Last();
	void Prepend(T data);
	void Append(T data);
	void Purge();
	void Extract(T data);
	void RemoveLast();
	void RemoveFirst();
	void InsertAfter(T lookfordata, T nndata);
	void InsertBefore(T lookfordata, T nndata);
	Node<T> * getHead() const;
	Node<T> * getTail() const;
	void PrintForwards();
	void PrintBackwards();

private:
	Node<T> * m_Head;
	Node<T> * m_Tail;
};


template<typename T>
inline List<T>::List() : m_Head(nullptr), m_Tail(nullptr)
{
}

template<typename T>
inline List<T>::List(const List & copy)
{

	*this = copy;
}

template<typename T>
inline List<T>::~List()
{
	Purge();
}

template<typename T>
inline List<T> & List<T>::operator=(const List<T> & rhs)
{
	if (this != &rhs) //if left hand side is not the same as the rhs
	{
		Node<T> * travel = rhs.m_Head;
		this->Purge();
		while (travel)
		{
			this->Append(travel->m_Data);
			travel = travel->m_right;
		}

	}

	return *this;
}

template<typename T>
inline bool List<T>::isEmpty()
{
	bool empty = true; //bool to hold if lists contains any nodes
	if (m_Head != nullptr)
	{
		empty = false; //if not empty return false
	}
	return empty;
}

template<typename T>
inline const T & List<T>::First()
{
	if (isEmpty())  //if the list isn't empty
		throw Exception("No Data in First list is empty"); //otherwise throw an exception
	return m_Head->m_Data; //return the data at the head node

}

template<typename T>
inline const T & List<T>::Last()
{
	if (isEmpty())
		throw Exception("No Data in Last list is empty"); //otherwise throw exception that list was empty
	return m_Tail->m_Data; //if list isn't empty return data at tail
}

template<typename T>
inline void List<T>::Prepend(T data)
{
	Node<T> * NN = new Node<T>(data); //create a new node that holds the data

	if (!isEmpty()) //if list isn't empty
	{
		NN->m_left = nullptr; //set the new node previous to nullptr
		NN->m_right = m_Head; //set the new nodes next to current head
		m_Head->m_left = NN; //make the current heads previous the new node
		m_Head = NN; //make the NN the Head
	}
	else //If no nodes currently exists in the list
	{
		m_Head = NN; //Make the Head the new node
		m_Tail = m_Head; //make the Tail the Head
	}

}

template<typename T>
inline void List<T>::Append(T data)
{
	Node<T> * NN = new Node<T>(data); // make a new node that holds the passed in data

	if (!isEmpty()) //if the list isn't empty
	{
		NN->m_right = nullptr; // set the next to nll ptr
		NN->m_left = m_Tail; //make new nodes prev the tail
		m_Tail->m_right = NN; // makes tails next the new node
		m_Tail = NN; // make the NN the tail
	}
	else
	{
		m_Head = NN; // make the head the NN
		m_Tail = m_Head; // make the tail the head
	}
}

template<typename T>
inline void List<T>::Purge()
{
	if (m_Head) //if the head exists
	{
		Node<T> * travel = m_Head; // make a travel that starts at the head
		while (travel) //while the travel exists
		{
			m_Head = m_Head->m_right; // make the head heads next
			delete travel; //delete the old head
			travel = nullptr;
			travel = m_Head; //make travel the new head
		}
		travel = nullptr;
	}
	m_Head = nullptr; //make sure the m_head is nullptr
	m_Tail = nullptr; //make sure the tail is nullptr

}

template<typename T>
inline void List<T>::Extract(T data)
{
	if (!isEmpty())
	{
		Node<T> * travel = m_Head; //make a new node travel
		while (travel != nullptr && travel->m_Data != data) //if the travel isn't null ptr and travels data isn't the same as the passed in data
		{
			travel = travel->m_right; //go to the next node
		}
		if (travel != nullptr) //if the data is found in the list
		{
			if (travel->m_Data == m_Head->m_Data) //check if the data was at the head
			{
				travel->m_right->m_left = nullptr; //if the data was the head set the second nodes previous to nullptr
				m_Head = travel->m_right; //make the second node the head
			}
			else if (travel->m_Data == m_Tail->m_Data)
			{
				travel->m_left->m_right = nullptr;
				m_Tail = travel->m_left;
			}
			else
			{
				travel->m_right->m_left = travel->m_left;
				travel->m_left->m_right = travel->m_right;
			}
			delete travel;

		}
		else
		{
			throw Exception("The data you were looking for wasn't in the list");
		}

	}
	else
	{
		throw Exception("The List was empty");
	}

}

template<typename T>
inline void List<T>::RemoveLast()
{
	if (m_Tail != nullptr)
	{
		if (m_Tail == m_Head)
		{
			delete m_Head;
			m_Head = nullptr;
			m_Tail = nullptr;
		}
		else
		{
			Node<T> * temp = m_Tail;
			m_Tail->m_left->m_right = nullptr;
			m_Tail = m_Tail->m_left;
			delete temp;
		}
	}
}

template<typename T>
inline void List<T>::RemoveFirst()
{
	if (m_Head != nullptr)
	{
		if (m_Tail == m_Head)
		{
			delete m_Head;
			m_Head = nullptr;
			m_Tail = nullptr;
		}
		else
		{
			Node<T> * temp = m_Head;
			m_Head->m_right->m_left = nullptr;
			m_Head = m_Head->m_right;
			delete temp;
		}
	}
}

template<typename T>
inline void List<T>::InsertAfter(T lookfordata, T nndata)
{
	Node<T> * NN = new Node<T>(nndata);
	Node<T> * temp = new Node<T>(lookfordata);
	Node<T> * travel = m_Head;
	if (travel != nullptr)
	{
		while (travel != nullptr && temp->m_Data != travel->m_Data)
		{
			travel = travel->m_right;
		}
		if (travel != nullptr)
		{
			if (temp->m_Data == m_Head->m_Data)
			{
				m_Head->m_right->m_left = NN;
				NN->m_right = m_Head->m_right;
				NN->m_left = m_Head;
				m_Head->m_right = NN;
			}
			else if (temp->m_Data == m_Tail->m_Data)
			{
				m_Tail->m_right = NN;
				NN->m_left = m_Tail;
				NN->m_right = nullptr;
				m_Tail = NN;
			}
			else
			{
				travel->m_right->m_left = NN;
				NN->m_right = travel->m_right;
				travel->m_right = NN;
				NN->m_left = travel;
			}
		}
		else
		{
			delete temp;
			delete NN;
			throw Exception("Can't insertafter because data you were looking for wasn't in List");

		}
	}
	else
	{
		delete temp;
		delete NN;
		throw Exception("List is empty can insert After anything in Empty List");
	}
	delete temp;
}

template<typename T>
inline void List<T>::InsertBefore(T lookfordata, T nndata)
{
	Node<T> * NN = new Node<T>(nndata);
	Node<T> * temp = new Node<T>(lookfordata);
	Node<T> * travel = m_Head;
	if (travel != nullptr)
	{
		while (travel != nullptr && temp->m_Data != travel->m_Data)
		{
			travel = travel->m_right;
		}
		if (travel != nullptr)
		{
			if (temp->m_Data == m_Head->m_Data)
			{
				NN->m_left = nullptr;
				NN->m_right = m_Head;
				m_Head->m_left = NN;
				m_Head = NN;
			}
			else if (temp->m_Data == m_Tail->m_Data)
			{
				m_Tail->m_left->m_right = NN;
				NN->m_left = m_Tail->m_left;
				m_Tail->m_left = NN;
				NN->m_right = m_Tail;
			}
			else
			{
				travel->m_left->m_right = NN;
				NN->m_left = travel->m_left;
				NN->m_right = travel;
				travel->m_left = NN;
			}

		}
		else
		{
			delete temp;
			delete NN;
			throw Exception("The data you were looking for wasn't in the list!");
		}
	}
	else
	{
		delete temp;
		delete NN;
		throw Exception("Your list is Empty!");
	}
	delete temp;
}

template<typename T>
inline Node<T> * List<T>::getHead() const
{
	return m_Head;
}

template<typename T>
inline Node<T> * List<T>::getTail() const
{
	return m_Tail;
}

template<typename T>
inline void List<T>::PrintForwards()
{
	if (m_Head)
	{
		Node<T> * travel = m_Head;
		while (travel != nullptr)
		{
			cout << travel->m_Data << ' ';
			travel = travel->m_right;
		}
	}
	else
	{
		throw Exception("Can't Print List is empty");
	}
}

template<typename T>
inline void List<T>::PrintBackwards()
{
	if (m_Head)
	{
		Node<T> * travel = m_Tail;
		while (travel != nullptr)
		{
			cout << travel->m_Data << ' ';
			travel = travel->m_left;
		}
	}
	else
	{
		throw Exception("Can't Print List is empty");
	}
}

#endif LIST_H

