#include <iostream>
using std::cout;
#include "AVL.h"

int main()
{

	AVL<int> testtree;

	

	return 0;
}