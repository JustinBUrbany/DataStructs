#ifndef AVL_H
#define AVL_H
#include "BinarySearchTree.h"



template<typename T>
class AVL : BinaryTree<T>
{

public:
	AVL();
	AVL(AVL & copy);
	~AVL();
	AVL & operator =(AVL & rhs);
	void Insert(T data);

private:
	void Insert(Node<T> *& root, T data, bool & taller);
	void RightBalance(Node<T> * & root, bool & taller);
	void LeftBalance();

};


#endif

template<typename T>
inline AVL<T>::AVL()
{
	BinaryTree();
}

template<typename T>
inline AVL<T>::AVL(AVL & copy)
{
}

template<typename T>
inline AVL<T>::~AVL()
{
	~BinaryTree();
}

template<typename T>
inline AVL<T> & AVL<T>::operator=(AVL & rhs)
{
	if (this != &rhs)
	{
		
	}
}

template<typename T>
inline void AVL<T>::Insert(T data)
{
	bool taller = false;
	Insert(m_root, data, taller);
}

template<typename T>
inline void AVL<T>::Insert(Node<T>*& root, T data, bool & taller)
{
	if (!root)
	{
		root = new Node<T>(data);
		taller = true;
	}
	else if (data < root->m_Data)
	{
		Insert(root->m_left, data, taller);
		if (taller)
		{
			switch (root->nodebalance)
			{
			case LEFTB: //Was 1 so now is 2
				break;
			case EQUAL: //Was equal so now is 1
				root->nodebalance = 1;
				break;
			case RIGHTB:
				root->nodebalance = 0;
				break;
			}
		}
	}
	else
	{
		Insert(root->m_right, data, taller);
		{
			if (taller)
			{
				switch (root->nodebalance)
				{
				case RIGHTB:
					RightBalance(root, taller);
					break;
				case EQUAL:
					root->nodebalance = -1;
					break;
				case LEFTB:
					root->nodebalance = 0;
					break;
				}
			}
		}
	}
}

template<typename T>
inline void AVL<T>::RightBalance(Node<T> * & root, bool & taller)
{
	//Node<T> * rootofproblemsleft = root->m_right->m_left; // T2
	Node<T> * problem = root; // T1
	root = root->m_right; //Set the root of the problem to the new root
	problem->m_right = root->m_left;// set root problems left child to old roots right
	root->m_left = problem; // set old root to new roots left
	 
}

template<typename T>
inline void AVL<T>::LeftBalance()
{
	Node<T> * problem = root;
	root = root->m_left;
	problem->m_left = root->m_right;
	root->m_right = problem;

}
