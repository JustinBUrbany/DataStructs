#ifndef QUEUELL_H
#define QUEUELL_H
#include "List.h"
#include "Exception.h"

template<typename T>
class QueueLL
{
public:
	QueueLL();
	QueueLL(QueueLL & copy);
	~QueueLL();
	QueueLL & operator=(QueueLL & rhs);
	int Size();
	bool isEmpty();
	void Engueue(T data);
	T Dequeue();
	T & Front();

private:
	int m_current_items;
	List<T> m_queue;


};


#endif

template<typename T>
inline QueueLL<T>::QueueLL() :m_current_items(-1)
{
}

template<typename T>
inline QueueLL<T>::QueueLL(QueueLL & copy)
{
	*this = copy;
	return *this;
}

template<typename T>
inline QueueLL<T>::~QueueLL()
{
	m_current_items = 0;
}

template<typename T>
inline QueueLL<T> & QueueLL<T>::operator=(QueueLL & rhs)
{
	m_current_items = rhs.m_current_items;
	m_queue = rhs.m_queue;
}

template<typename T>
inline int QueueLL<T>::Size()
{
	return m_current_items + 1;
}

template<typename T>
inline bool QueueLL<T>::isEmpty()
{
	bool empty = false;
	if (m_current_items < 0)
	{
		empty = true;
	}
	return empty;
}

template<typename T>
inline void QueueLL<T>::Engueue(T data)
{

	m_queue.Append(data);
	m_current_items++;
}

template<typename T>
inline T QueueLL<T>::Dequeue()
{
	if (isEmpty())
		throw Exception("Queue is empty");
	m_current_items--;
	T temp = m_queue.First();
	m_queue.RemoveFirst();

	return temp;

}

template<typename T>
inline T & QueueLL<T>::Front()
{
	if (isEmpty())
		throw Exception("Queue is empty");
	T temp = m_queue.First();
	return temp;
}

