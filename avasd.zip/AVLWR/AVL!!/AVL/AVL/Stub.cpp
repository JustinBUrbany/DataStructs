#include <iostream>
using std::cout;
using std::endl;
#include "AVL.h"

template<typename T>
void PrintTree(T data);


int main()
{

	AVL<int> testtree;

	testtree.Insert(7);
	testtree.Insert(10);
	testtree.Insert(13);
	testtree.Insert(15);
	testtree.Insert(14);
	testtree.Print(PrintTree);
	
	cout << endl;

	//testtree.Insert(25);
	//testtree.Insert(3);
	testtree.Print(PrintTree);


	return 0;
}


template<typename T>
void PrintTree(T data)
{
	cout << data << ' ';
}