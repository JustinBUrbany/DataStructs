#ifndef AVL_H
#define AVL_H
#include "BinarySearchTree.h"



template<typename T>
class AVL : BinaryTree<T>
{
public:
	AVL();
	AVL(AVL & copy);
	~AVL();
	AVL & operator =(AVL & rhs);
	void Insert(T data);
	void Print(void(*Visit)(T));

private:
	void Insert(Node<T> *& root, T data, bool & taller);
	void RightBalance(Node<T> * & root, bool & taller);
	void LeftBalance(Node<T> * & root, bool & taller);


};


#endif

template<typename T>
inline AVL<T>::AVL()
{
	BinaryTree();
}

template<typename T>
inline AVL<T>::AVL(AVL & copy)
{
}

template<typename T>
inline AVL<T>::~AVL()
{
	
}

template<typename T>
inline AVL<T> & AVL<T>::operator=(AVL & rhs)
{
	if (this != &rhs)
	{
		Purge();
		if (rhs != nullptr)
		{
			*this = rhs;
		}
	}

	return *this;
}

template<typename T>
inline void AVL<T>::Insert(T data)
{
	bool taller = false;
	Insert(m_root, data, taller);
}

template<typename T>
inline void AVL<T>::Print(void(*Visit)(T))
{
	Breath_First_Traversal(Visit);
}

template<typename T>
inline void AVL<T>::Insert(Node<T>*& root, T data, bool & taller)
{
	if (!root)
	{
		root = new Node<T>(data);
		taller = true;
	}
	else if (data < root->GetData())
	{
		Insert(root->GetLeft(), data, taller);
		if (taller)
		{
			switch (root->GetBalance())
			{
			case 1: //Was 1 so now is 2
				LeftBalance(root, taller);
				break;
			case 0: //Was equal so now is 1
				root->SetBalance(root->LEFTB);
				break;
			case -1:
				root->SetBalance(root->EQUAL);
				break;
			}
		}
	}
	else
	{
		Insert(root->GetRight(), data, taller);
		{
			if (taller)
			{
				switch (root->GetBalance())
				{
				case -1://now -2
					RightBalance(root, taller);
					break;
				case 0:
					root->SetBalance( root->RIGHTB);
					break;
				case 1:
					root->SetBalance(root->EQUAL);
					break;
				}
			}
		}
	}
}

template<typename T>
inline void AVL<T>::RightBalance(Node<T> * & root, bool & taller)
{
	int nheight=0;
	int rheight=0;
	int leftheight=0;
	Node<T> * problem = root;
	root = root->GetRight(); //Set the root of the problem to the new root
	problem->GetRight() = root->GetLeft();// set root problems left child to old roots right
	root->GetLeft() = problem; // set old root to new roots left

	//rheight = Height(problem->GetRight());
	//leftheight = Height(problem->GetLeft());
	//nheight = leftheight - rheight;

	//if (nheight == -1)
	//{
	//	problem->SetBalance(problem->RIGHTB);
	//	taller = true;
	//}
	//else if (nheight == 0)
	//{
	//	problem->SetBalance(problem->EQUAL);
	//	taller = false;
	//}
	//else
	//{
	//	problem->SetBalance(problem->LEFTB);
	//	taller = true;
	//}

	//rheight = Height(root->GetRight());
	//leftheight = Height(root->GetLeft());
	//nheight = leftheight - rheight;
	//if (nheight == -1)
	//{
	//	root->SetBalance(root->RIGHTB);
	//	taller = true;
	//}
	//else if (nheight == 0)
	//{
	//	root->SetBalance(root->EQUAL);
	//	taller = false;
	//}
	//else
	//{
	//	root->SetBalance(root->LEFTB);
	//	taller = true;
	//}

	

}

template<typename T>
inline void AVL<T>::LeftBalance(Node<T> * & root, bool & taller)
{
	int nheight = 0;
	int rheight = 0;
	int leftheight = 0;

	Node<T> * problem = root;
	root = root->GetLeft();
	problem->GetLeft() = root->GetRight();
	root->GetRight() = problem;

	rheight = Height(problem->GetRight());
	leftheight = Height(problem->GetLeft());
	nheight = leftheight - rheight;

	/*if (nheight == -1)
	{
		problem->SetBalance(problem->RIGHTB);
		taller = true;
	}
	else if (nheight == 0)
	{
		problem->SetBalance(problem->EQUAL);
		
	}
	else
	{
		problem->SetBalance(problem->LEFTB);
		taller = true;
	}

	rheight = Height(root->GetRight());
	leftheight = Height(root->GetLeft());
	nheight = leftheight - rheight;

	if (nheight == -1)
	{
		root->SetBalance(root->RIGHTB);
		taller = true;
	}
	else if (nheight == 0)
	{
		root->SetBalance(root->EQUAL);
		taller = false;

	}
	else
	{
		root->SetBalance(root->LEFTB);
		taller = true;

	}*/


}
