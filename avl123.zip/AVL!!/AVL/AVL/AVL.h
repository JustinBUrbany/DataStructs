/*************************************************************
* Author:		Justin.Urbany
* Filename:		Exception.h
* Date Created:	1/23/17
* Modifications:	1/24/17-added comments
**************************************************************/
#ifndef AVL_H
#define AVL_H
#include "BinarySearchTree.h"
/************************************************************************
* Class: Exception
*
* Purpose: Creates a character message to throw to user when error occurs
*
* Manager functions:
* 	Exception ( )
*	Exception (char * msg)
*		Create exception allocate space and intialize message
*	Exception (const Exception & copy)
*		Create a copy of an exceptinA
*	operator = (const Exception & copy)
*		set one Exception equal to the other ExceptionA
*	~Exception()
*		clear memory for the Exception
*
* Methods:
*	const char * getMessage() returns the current message in the exception
*	void setMessage(char * msg) set the current message in the exception
*************************************************************************/
template<typename T>
class AVL : BinaryTree<T>
{
public:
	AVL();
	AVL(AVL & copy);
	~AVL();
	AVL & operator =(AVL & rhs);
	void Insert(T data);
	void Print(void(*Visit)(T));
	void Delete(T data);
private:
	void Insert(Node<T> *& root, T data, bool & taller);
	void Delete(Node<T> *& root, T data, bool & smaller);
	void DeleteRB(Node<T> *&root, bool & smaller);
	void DeleteLB(Node<T> *&root, bool & smaller);
	void RightBalance(Node<T> * & root, bool & taller);
	void LeftBalance(Node<T> * & root, bool & taller);
	void RightRotate(Node<T> *& root);
	void LeftRotate(Node<T> *& root);
};
#endif
/**********************************************************************
* Purpose:
*
* Precondtion:
*
* Postcondition:
*
************************************************************************/
template<typename T>
inline AVL<T>::AVL()
{
	BinaryTree();
}
/**********************************************************************
* Purpose:
*
* Precondtion:
*
* Postcondition:
*
************************************************************************/
template<typename T>
inline AVL<T>::AVL(AVL & copy)
{
	*this = copy;
}
/**********************************************************************
* Purpose:
*
* Precondtion:
*
* Postcondition:
*
************************************************************************/
template<typename T>
inline AVL<T>::~AVL()
{
	
}
/**********************************************************************
* Purpose:
*
* Precondtion:
*
* Postcondition:
*
************************************************************************/
template<typename T>
inline AVL<T> & AVL<T>::operator=(AVL & rhs)
{
	if (this != &rhs)
	{
		Purge();
		m_root = nullptr;
		if (!rhs.isEmpty())
		{
			Node<T> * current = rhs.m_root;
			QueueLL<Node<T>*> equalque;
			//Do Breath-First traversal With an Insert instead of Print statement
			while (current != nullptr)
			{
				Insert(current->GetData());

				if (current->GetLeft() != nullptr)
				{
					equalque.Engueue(current->GetLeft());
				}
				if (current->GetRight() != nullptr)
				{
					equalque.Engueue(current->GetRight());
				}

				if (!equalque.isEmpty())
				{
					current = equalque.Front();
					equalque.Dequeue();
				}
				else
				{
					current = nullptr;
				}
			}
		}
	}
	return *this;
}
/**********************************************************************
* Purpose:
*
* Precondtion:
*
* Postcondition:
*
************************************************************************/
template<typename T>
inline void AVL<T>::Insert(T data)
{
	bool taller = false;
	Insert(m_root, data, taller);
}
/**********************************************************************
* Purpose:
*
* Precondtion:
*
* Postcondition:
*
************************************************************************/
template<typename T>
inline void AVL<T>::Print(void(*Visit)(T))
{
	Breath_First_Traversal(Visit);
}
/**********************************************************************
* Purpose:
*
* Precondtion:
*
* Postcondition:
*
************************************************************************/
template<typename T>
inline void AVL<T>::Delete(T data)
{
	bool smaller = false;
	Delete(m_root, data, smaller);
}
/**********************************************************************
* Purpose:
*
* Precondtion:
*
* Postcondition:
*
************************************************************************/
template<typename T>
inline void AVL<T>::Insert(Node<T>*& root, T data, bool & taller)
{
	if (!root)
	{
		root = new Node<T>(data);
		taller = true;
	}
	else if (data < root->GetData())
	{
		Insert(root->GetLeft(), data, taller);
		if (taller)
		{
			switch (root->GetBalance())
			{
			case 1: //Was 1 so now is 2
				LeftBalance(root, taller);
				break;
			case 0: //Was equal so now is 1
				root->SetBalance(root->LEFTB);
				break;
			case -1:
				root->SetBalance(root->EQUAL);
				break;
			}
		}
	}
	else
	{
		Insert(root->GetRight(), data, taller);
		{
			if (taller)
			{
				switch (root->GetBalance())
				{
				case -1://now -2
					RightBalance(root, taller);
					break;
				case 0:
					root->SetBalance( root->RIGHTB);
					break;
				case 1:
					root->SetBalance(root->EQUAL);
					break;
				}
			}
		}
	}
}
/**********************************************************************
* Purpose:
*
* Precondtion:
*
* Postcondition:
*
************************************************************************/
template<typename T>
inline void AVL<T>::Delete(Node<T>*& root, T data, bool & smaller)
{
	Node<T> * temp;
	if (!root)
	{
		throw Exception("The node wasn't in your tree");
		smaller = false;
	}
	if (root->GetData() > data)
	{
		Delete(root->GetLeft(), data, smaller);
		if (smaller)
		{
			DeleteRB(root, smaller);
		}
		
	}
	else if (root->GetData() < data)
	{
		Delete(root->GetRight(), data, smaller);
		if (smaller)
		{
			DeleteLB(root, smaller);
		}
	}
	else
	{
		if (!root->GetRight() && !root->GetLeft())//check if leaf node
		{
			delete root;
			root = nullptr;
			shorter = true;
		}
		else if (!root->GetRight()) //no Right subtree
		{
			temp = root;
			root = root->m_left();
			delete temp;
			temp = nullptr;
			shorter = true;
		}
		else if (!root->GetLeft())
		{
			temp = root;
			root = root->m_right();
			delete temp;
			temp = nullptr;
			shorter = true;
		}
		else
		{
			Node<T> * temp2;
			temp = root;
			temp2=m
		}
	}
}
/**********************************************************************
* Purpose:
*
* Precondtion:
*
* Postcondition:
*
************************************************************************/
template<typename T>
inline void AVL<T>::DeleteRB(Node<T>*& root, bool & smaller)
{
}
/**********************************************************************
* Purpose:
*
* Precondtion:
*
* Postcondition:
*
************************************************************************/
template<typename T>
inline void AVL<T>::DeleteLB(Node<T>*& root, bool & smaller)
{
}
/**********************************************************************
* Purpose:
*
* Precondtion:
*
* Postcondition:
*
************************************************************************/
template<typename T>
inline void AVL<T>::RightBalance(Node<T> * & root, bool & taller)
{
	//Node<T> * leftTree;
	//Node<T> * rightTree = root->GetRight();

	//switch (rightTree->GetBalance())
	//{
	//case -1: /// This will Be the RR 
	//	root->SetBalance(Node<T>::EQUAL);
	//	rightTree->SetBalance(Node<T>::EQUAL);
	//	RightRotate(root);
	//	taller = false;
	//	break;
	//case 0:
	//	//This is an Eroor
	//	break;
	//case 1: //This is going to be the LR rotation
	//	leftTree = rightTree->GetLeft();
	//	switch (leftTree->GetBalance())
	//	{
	//	case 1:
	//		root->SetBalance(Node<T>::EQUAL);
	//		rightTree->SetBalance(Node<T>::LEFTB);
	//		break;
	//	case 0:
	//		root->SetBalance(Node<T>::EQUAL);
	//		rightTree->SetBalance(Node<T>::EQUAL);
	//		break;
	//	case -1:
	//		root->SetBalance(Node<T>::RIGHTB);
	//		rightTree->SetBalance(Node<T>::EQUAL);
	//		break;
	//	}
	//	leftTree->SetBalance(Node<T>::EQUAL);

	//	LeftRotate(rightTree);
	//	RightRotate(root);
	//	taller = false;
	//	break;
	//}




	int nheight=0;
	int rheight=0;
	int leftheight=0;
	

	if (root->GetRight()->GetBalance() == 1)
	{
		LeftRotate(root->GetRight());
	}

	RightRotate(root);

	rheight = Height(root->GetRight()); //problem is the new child
	leftheight = Height(root->GetLeft());// root is the new root
	nheight = leftheight - rheight;

	if (nheight == -1)
	{
		root->SetBalance(root->RIGHTB);
	}
	else if (nheight == 0)
	{
		root->SetBalance(root->EQUAL);
	}
	else
	{
		root->SetBalance(root->LEFTB);
	}

	rheight = Height(root->GetLeft()->GetRight());
	leftheight = Height(root->GetLeft()->GetLeft());
	nheight = leftheight - rheight;

	if (nheight == -1)
	{
		root->GetLeft()->SetBalance(root->RIGHTB);
	}
	else if (nheight == 0)
	{
		root->GetLeft()->SetBalance(root->EQUAL);
	}
	else
	{
		root->GetLeft()->SetBalance(root->LEFTB);
	}

	taller = false;

}
/**********************************************************************
* Purpose:
*
* Precondtion:
*
* Postcondition:
*
************************************************************************/
template<typename T>
inline void AVL<T>::LeftBalance(Node<T> * & root, bool & taller)
{
	//Node<T> *rightTree;
	//Node<T> *leftTree=root->GetLeft();

	//switch (leftTree->GetBalance())
	//{
	//case 1://This is an LL so set the root and root of problem Balance to 0 then rotate left to rebalance
	//	root->SetBalance(Node<T>::EQUAL);//going to rotate so set new balance
	//	leftTree->SetBalance(Node<T>::EQUAL);//going to rotate so set new balance
	//	LeftRotate(root);//Do the Left rotate
	//	taller = false; //Reset taller since you did the rotation
	//	break;
	//case 0://This is an error
	//	break;
	//case -1: // This is going nto be our LR rotation so need to do both but do right first on lefts right child
	//	rightTree = leftTree->GetRight();
	//	switch (rightTree->GetBalance())
	//	{
	//	case 1:
	//		root->SetBalance(Node<T>::RIGHTB);
	//		leftTree->SetBalance(Node<T>::EQUAL);
	//		break;
	//	case 0:
	//		root->SetBalance(Node<T>::EQUAL);
	//		leftTree->SetBalance(Node<T>::EQUAL);
	//		break;
	//	case -1:
	//		root->SetBalance(Node<T>::EQUAL);
	//		leftTree->SetBalance(Node<T>::LEFTB);
	//		break;
	//	}

	//	rightTree->SetBalance(Node<T>::EQUAL);
	//	RightRotate(leftTree);
	//	LeftRotate(root);

	//}



	//rheight = Height(problem->GetRight());
	//leftheight = Height(problem->GetLeft());
	//nheight = leftheight - rheight;

	int nheight = 0;
	int rheight = 0;
	int leftheight = 0;

	if (root->GetLeft()->GetBalance() == -1)
	{
		RightRotate(root->GetLeft());
	}

	LeftRotate(root);
	rheight = Height(root->GetRight());
	leftheight = Height(root->GetLeft());
	nheight = leftheight - rheight;
	if (nheight == -1)
	{
		root->SetBalance(root->RIGHTB);
	}
	else if (nheight == 0)
	{
		root->SetBalance(root->EQUAL);
	}
	else
	{
		root->SetBalance(root->LEFTB);
	}

	rheight = Height(root->GetRight()->GetRight());
	leftheight = Height(root->GetRight()->GetLeft());
	nheight = leftheight - rheight;
	if (nheight == -1)
	{
		root->GetRight()->SetBalance(root->RIGHTB);
	}
	else if (nheight == 0)
	{
		root->GetRight()->SetBalance(root->EQUAL);
	}
	else
	{
		root->GetRight()->SetBalance(root->LEFTB);
	}

	taller = false;

}
/**********************************************************************
* Purpose:
*
* Precondtion:
*
* Postcondition:
*
************************************************************************/
template<typename T>
inline void AVL<T>::RightRotate(Node<T>*& root)
{
	Node<T> * problem = root;
	root = root->GetRight(); //Set the root of the problem to the new root
	problem->GetRight() = root->GetLeft();// set root problems left child to old roots right
	root->GetLeft() = problem; // set old root to new roots left
}
/**********************************************************************
* Purpose:
*
* Precondtion:
*
* Postcondition:
*
************************************************************************/
template<typename T>
inline void AVL<T>::LeftRotate(Node<T>*& root)
{
	Node<T> * problem = root;
	root = root->GetLeft();
	problem->GetLeft() = root->GetRight();
	root->GetRight() = problem;
}
